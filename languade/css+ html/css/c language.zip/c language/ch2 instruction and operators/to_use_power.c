#include<stdio.h>
#include<math.h>
int main (){
    // int 4,2;
    printf("the power of 4^2 (2 on 4) is %f",pow (4,2));
return 0;
}