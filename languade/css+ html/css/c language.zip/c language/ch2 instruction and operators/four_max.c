#include<stdio.h>
int main(){
    int max=0;
    printf("9999 is max you can go",max);
    return 0;
}