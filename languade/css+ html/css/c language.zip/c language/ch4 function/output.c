#include <stdio.h>

int main (){
int a=0;
printf("%d%d%d\n",a,++a,a++);
return 0;
}