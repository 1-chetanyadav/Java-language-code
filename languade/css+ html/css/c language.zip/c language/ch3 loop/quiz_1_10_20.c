#include <stdio.h>
int main()
{
    int z =0;

    while (z <= 20)
    {
        if (z >= 10)
        {
            printf("\n%d", z);
        }

        z++;
    }
    return 0;
}