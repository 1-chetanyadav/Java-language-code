#include <stdio.h>
int main()
{
    int counter;
    printf("\n\ntype a number\n");
   
    while (counter < 199)
    {
        printf("%d\n", counter);
        counter++;
    }
    return 0;
    
}