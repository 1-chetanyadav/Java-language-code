#include <stdio.h>
int main()
{
    int input=1;
    printf("type a number for four natural number \n");
    // scanf("%d", &input);
    for (input>5;input>10;++input)
    {
        printf("%d\n", input);
    }

    return 0;
}