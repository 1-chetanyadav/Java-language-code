#include <stdio.h>
int main ( ){
float celcius,ferenheit;
printf("what is the value of celcius",celcius);
scanf("%f",&celcius);
printf("the value of ferenheit is %f",celcius*9/5+32);
    return 0;
}


//     float celcius=22;
//     float ferenheit;
    
// printf("the ferenheit is %f",celcius*9/5+32);